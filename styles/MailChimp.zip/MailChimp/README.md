Based on [MailChimp](http://styleguide.mailchimp.com/).
