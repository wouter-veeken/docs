Based on jQuery's [Prose Style Guide](https://contribute.jquery.org/style-guide/prose/).
