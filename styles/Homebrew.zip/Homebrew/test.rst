- run `brew update` (twice)
- run and read `brew doctor`
- read [the Troubleshooting Checklist](http://docs.brew.sh/Troubleshooting.html)
- open an issue on the formula's repository or on Homebrew/brew if it's not a formula-specific issue

The |biohazard| symbol must be used on TODO containers used to dispose of medical waste.

+------------+------------+-----------+
| TODO       | Header 2   | XXX       |
+============+============+===========+
| body row 1 | use git to | column 3  |
+------------+------------+-----------+
| body row 2 | Cells may span columns.|
+------------+------------+-----------+
| FIXME      | Cells may  | - Cells   |
+------------+ span rows. | - contain |
| body row 4 |            | - blocks. |
+------------+------------+-----------+


**TODO** this is a sentence ``TODO`` XXX.

.. |biohazard| image:: biohazard.png
