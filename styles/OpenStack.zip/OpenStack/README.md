Based on [OpenStack](https://docs.openstack.org/contributor-guide/writing-style.html).
