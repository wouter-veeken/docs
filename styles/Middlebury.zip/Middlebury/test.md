The cost is $50-$55. Back in the '80s.

The oriental man walked by. We went on a month-long trip (i.e. we were gone for a month).

People with autism, Down syndrome, dyslexia, blindness, ADHD, or cystic fibrosis, for example, may be considered to have special needs.

Our campus is known world-wide.
