Based on the [Middlebury Editorial Style Guide](https://middlebury.github.io/styleguide/editorial/).
