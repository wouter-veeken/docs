According to Wikipedia, the World Health Organization (WHO) is a specialized agency of the United Nations that is concerned with international public health. We can now use WHO because it has been defined, but we can't use DAFB because people may not know what it represents.

```
We can say anything in here -- even XYZ.
```

ESPN doesn't require a definition since it's listed as an exception. The NBA, NFL, and MLB are also common. (We should expand the exceptions list to include all abbreviations that appear as word entries in Merriam-Webster's Collegiate Dictionary.)

The acronym AAAS stands for the American Association for the Advancement of Science, but it doesn't count because the definition came after its usage (ie it wasn't defined after).

This was a community outreach program. You really should know that! Consider, for example, this:
