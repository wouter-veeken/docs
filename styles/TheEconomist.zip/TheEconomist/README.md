Based on [The Economist](http://www.economist.com/styleguide/introduction).
