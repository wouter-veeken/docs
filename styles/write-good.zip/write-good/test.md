Remarkably few developers write well.

The script was killed

the the

the
the

The the

// //

So the best thing to do is wait.

So?

This changes the code so that it works.

Some silly sausages start sentences stating so.
Sorry, everyone.

This is a test; so it should pass or fail.

There is a use for this construction.

There are uses for this construction.

This sentence is simply terrible

This sentence is extremely good.

It has been said that few developers write well.

As a matter of fact, this sentence could be simpler.

Your readers will be adversely impacted by this sentence.

Writing specs puts me at loose ends.
